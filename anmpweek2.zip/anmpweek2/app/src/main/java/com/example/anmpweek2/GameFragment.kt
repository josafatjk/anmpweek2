package com.example.anmpweek2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_game.*

class GameFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_game, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var corrAnswer = 0
        val txtVal1 = view.findViewById<TextView>(R.id.txtVal1)
        val txtVal2 = view.findViewById<TextView>(R.id.txtVal2)

        val val1 = (0..100).shuffled().last().toString()
        val val2 = (0..100).shuffled().last().toString()

        txtVal1.text = val1
        txtVal2.text = val2

        val txtAnswer = view.findViewById<TextView>(R.id.txtAnswer)
        var result = txtVal1.text.toString().toInt() + txtVal2.text.toString().toInt()

        if (arguments != null) {
            val playerName = GameFragmentArgs.fromBundle(requireArguments()).playerName
            val txtTurn = view.findViewById<TextView>(R.id.txtTurn)
            txtTurn.text = "$playerName's Turn"
        }
        val btnAnswer = view.findViewById<Button>(R.id.btnAnswer)

        btnAnswer.setOnClickListener {
            if (txtAnswer.text.toString() == result.toString()) {

                corrAnswer += 1

                txtVal1.text = (0..100).shuffled().last().toString()
                txtVal2.text = (0..100).shuffled().last().toString()
                result = txtVal1.text.toString().toInt() + txtVal2.text.toString().toInt()
                txtAnswer.text = ""
            } else {
                val actionResult = GameFragmentDirections.actionResultFragment(corrAnswer)
                Navigation.findNavController(it).navigate(actionResult)
            }
        }
    }
}